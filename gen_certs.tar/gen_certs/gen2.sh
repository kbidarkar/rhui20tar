DEST=$1
CN=$2

CERT_CONFIG="/root/gen_certs/gen.cfg"

# Substitute in the CN into the template and make the correct config
sed -e "s/CCNN/$CN/g" /root/gen_certs/gen.cfg.template > /root/gen_certs/gen.cfg

# Put generated files in their own directory
mkdir -p /root/gen_certs/build


# Server
# --------------------
echo $CERT_CONFIG
#  Generate request
openssl req -new -key /root/gen_certs/server.key -out /root/gen_certs/server.csr -config $CERT_CONFIG

#  Sign it
openssl x509 -req -days 365 -in /root/gen_certs/server.csr -CA /root/gen_certs/ca2.crt -CAkey /root/gen_certs/ca2.key -set_serial 06 -out /root/gen_certs/build/$DEST
